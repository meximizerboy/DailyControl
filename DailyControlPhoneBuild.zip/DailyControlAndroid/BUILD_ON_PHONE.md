# Build Daily Control APK using only an Android phone

The project can be built without a computer by using GitHub Actions.

## Method A — GitHub Actions (recommended)

1. Create/sign in to a GitHub account.
2. Create a new repository, for example `DailyControl`.
3. Upload all files from this project into the repository. Keep the `.github/workflows/build-apk.yml` file.
4. Open the repository's **Actions** tab.
5. Select **Build Daily Control APK**.
6. Tap **Run workflow**.
7. Wait for the workflow to finish successfully.
8. Open the completed workflow run and download the artifact named **DailyControl-debug-apk**.
9. Extract the downloaded ZIP and install `app-debug.apk` on your Android phone.

Android may ask you to allow installation from the browser/file manager. Only enable that permission for the app you trust, and disable it again afterward.

## Method B — AndroidIDE

AndroidIDE can build Gradle-based Android projects directly on Android devices, but the original AndroidIDE project is no longer maintained. Use only a trusted release source. Then open this project, allow Gradle/SDK setup, and run the debug build.

## Important

This is a debug APK build. It is suitable for personal testing/use. A Play Store release would require a properly signed release build.
