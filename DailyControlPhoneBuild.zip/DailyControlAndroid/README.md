# Daily Control

Personal daily task, calendar, record and time-management Android app.

## Included

- Home dashboard
- Tasks with categories and priorities
- Daily / weekdays / weekly recurring tasks
- Task completion by date
- Monthly calendar
- Daily records
- Live clock
- Stopwatch
- Countdown timer
- Local persistent data using WebView DOM storage
- No external app runtime dependency

## Build

See `BUILD_ON_PHONE.md` for a phone-only GitHub Actions method.

For Android Studio, open this folder as a Gradle Android project and run the `app` configuration.
